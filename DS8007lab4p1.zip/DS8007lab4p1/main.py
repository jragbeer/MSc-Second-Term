import pandas as pd
import numpy as np
import datetime
import time
import sqlite3
import os
import glob
from bokeh.plotting import figure, show
from bokeh.models import BasicTickFormatter, HoverTool, LassoSelectTool, BoxSelectTool, BoxZoomTool, ResetTool, Span, FactorRange,OpenURL, CustomJS, DatetimeTickFormatter, LabelSet
from bokeh.models import NumeralTickFormatter, WheelZoomTool, PanTool, SaveTool, TapTool, PolySelectTool,ColumnDataSource, LinearAxis, Range1d, FuncTickFormatter, Band, Toggle, SingleIntervalTicker
from bokeh.models.widgets import Select, RadioGroup, DataTable, StringFormatter, TableColumn, NumberFormatter, Button, inputs, CheckboxButtonGroup, Div
from bokeh.layouts import widgetbox, row, column
from bokeh.events import ButtonClick, SelectionGeometry
from bokeh.io import curdoc
from bokeh.colors import Color
from bokeh.core.properties import Seq, Date
from os.path import dirname, join
from bokeh.models.widgets import TextInput

def clearcallback(event):
    global expression
    expression=''
    div2.text = expression

def timescallback(event):
    global expression
    if expression[-1] in ['/','+','*','-']:
        expression = expression[:-1]
    expression+='*'
    div2.text = expression
def dividecallback(event):
    global expression
    if expression[-1] in ['/','+','*','-']:
        expression = expression[:-1]
    expression+='/'
    div2.text = expression
def minuscallback(event):
    global expression
    if expression[-1] in ['/','+','*','-']:
        expression = expression[:-1]
    expression+='-'
    div2.text = expression
def pluscallback(event):
    global expression
    if expression[-1] in ['/','+','*','-']:
        expression = expression[:-1]
    expression+='+'
    div2.text = expression

def equalscallback(event):
    answer = pd.eval(expression)
    div2.text = str(answer)

def zerocallback(event):
    global expression
    expression+='0'
    div2.text = expression
def onecallback(event):
    global expression
    expression+='1'
    div2.text = expression

def twocallback(event):
    global expression
    expression+='2'
    div2.text = expression
def threecallback(event):
    global expression
    expression+='3'
    div2.text = expression
def fourcallback(event):
    global expression
    expression+='4'
    div2.text = expression
def fivecallback(event):
    global expression
    expression+='5'
    div2.text = expression
def sixcallback(event):
    global expression
    expression+='6'
    div2.text = expression
def sevencallback(event):
    global expression
    expression+='7'
    div2.text = expression
def eightcallback(event):
    global expression
    expression+='8'
    div2.text = expression
def ninecallback(event):
    global expression
    expression+='9'
    div2.text = expression

expression = ''

doc = curdoc()
#clears the html page and gives the tab a name
doc.clear()
doc.title = 'Homework 4 Question 1'

zerobutton = Button(label="0", button_type="primary")
zerobutton.on_event(ButtonClick, zerocallback)

onebutton = Button(label="1", button_type="primary")
onebutton.on_event(ButtonClick, onecallback)

twobutton = Button(label="2", button_type="primary")
twobutton.on_event(ButtonClick, twocallback)

threebutton = Button(label="3", button_type="primary")
threebutton.on_event(ButtonClick, threecallback)

fourbutton = Button(label="4", button_type="primary")
fourbutton.on_event(ButtonClick, fourcallback)

fivebutton = Button(label="5", button_type="primary")
fivebutton.on_event(ButtonClick, fivecallback)

sixbutton = Button(label="6", button_type="primary")
sixbutton.on_event(ButtonClick, sixcallback)

sevenbutton = Button(label="7", button_type="primary")
sevenbutton.on_event(ButtonClick, sevencallback)

eightbutton = Button(label="8", button_type="primary")
eightbutton.on_event(ButtonClick, eightcallback)

ninebutton = Button(label="9", button_type="primary")
ninebutton.on_event(ButtonClick, ninecallback)

plusbutton = Button(label="+", button_type="warning")
plusbutton.on_event(ButtonClick, pluscallback)

minusbutton = Button(label="-", button_type="warning")
minusbutton.on_event(ButtonClick, minuscallback)

timesbutton = Button(label="X", button_type="warning")
timesbutton.on_event(ButtonClick, timescallback)

dividebutton = Button(label="/", button_type="warning")
dividebutton.on_event(ButtonClick, dividecallback)

equalsbutton = Button(label="=", button_type="warning")
equalsbutton.on_event(ButtonClick, equalscallback)

clearbutton = Button(label="C", button_type="warning")
clearbutton.on_event(ButtonClick, clearcallback)

div2 = Div(text = '',width=900, height=130)

aa = row([onebutton, twobutton, threebutton, timesbutton])
bb = row([fourbutton,fivebutton,sixbutton, dividebutton])
cc = row([sevenbutton,eightbutton,ninebutton, equalsbutton])
dd = column([clearbutton, plusbutton, minusbutton])
ee = row([div2, dd])
ff = column([ee, aa,bb,cc])
doc.add_root(ff)
show(ff)

